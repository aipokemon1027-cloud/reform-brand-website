#!/bin/bash
# 日本不動產投資分析儀 - 安裝腳本
# 使用方式：bash install.sh

echo "🏠 安裝日本不動產投資分析儀..."

# 目標目錄
TARGET_DIR="${HOME}/.openclaw/workspace/skills/real-estate-analyzer-jp"

# 建立目錄
mkdir -p "$TARGET_DIR"

# 複製檔案
cp SKILL.md "$TARGET_DIR/"
cp README.md "$TARGET_DIR/"

echo "✅ SKILL.md → $TARGET_DIR/SKILL.md"
echo "✅ README.md → $TARGET_DIR/README.md"

echo ""
echo "✅ 安裝完成！"
echo ""
echo "使用方式：直接丢日本房源連結/截圖/數字給你的 AI Agent"
echo "它會自動觸發 10 步驟分析流程"
